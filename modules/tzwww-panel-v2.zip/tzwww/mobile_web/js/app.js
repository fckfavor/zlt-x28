/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-11-27 16:25:56
 * @,@LastEditTime: ,: 2021-04-14 13:57:25
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\app.js
 */
$(document).ready(function () {
    var web_browser_title = ""
    function init() {
        if(Page.logoPath !='logo_mexico_custom.png'){
            document.title = web_browser_title || DOC.head
        }else{
            document.title = "Quamtum Connect 1"
        }
        $.ajax({
            url: "/mobile_web/html/index.html",
            dataType: "html",
            type: "GET",
            async: false,
            success: function (data) {
                if (sessionStorage['canLogin'] == "AUTH"&&sessionStorage.getItem("pageUrl") =="html/index.html") {
                    $('#app').html(data);
                } else {
                    var pageUrl = sessionStorage.getItem("pageUrl")
                    $("#app").load(pageUrl)
                }
            }
        });
    }
    Page.postJSON({
        json: {
            cmd: RequestCmd.INIT_PAGE
        },
        success: function (data) {
            var styleTag = document.createElement("link");
            Page.webPageFlag = Page.parseHexPageHide(data.web_page_hide);
            var themeWeb = "";
            if (!data.user_web_theme) {
              themeWeb = "css/main.css";
            } else if(data.user_web_theme=="main.tot.css"){
              themeWeb = data.user_web_theme;
            }else{
              themeWeb = "css/main.css";
            }
            if (!!data.web_browser_title) {
                web_browser_title = data.web_browser_title;
            }
            styleTag.setAttribute('href', 'css/' + themeWeb);
            styleTag.setAttribute('type', 'text/css');
            styleTag.setAttribute('rel', 'stylesheet');
            $("head")[0].appendChild(styleTag);
            if( data.web_logo_path == "logo_t3.png") {
              var styleTag = document.createElement("link");
              styleTag.setAttribute('href', 't3_favicon.ico');
              styleTag.setAttribute('type', 'image/x-icon');
              styleTag.setAttribute('rel', 'shortcut icon');
              $("head")[0].appendChild(styleTag);
            }
            if( data.user_web_theme == 'main.tot.css') {
              var styleTag = document.createElement("link");
              styleTag.setAttribute('href', '/images/nn90j-whejs.png');
              styleTag.setAttribute('type', 'image/x-icon');
              styleTag.setAttribute('rel', 'shortcut icon');
              $("head")[0].appendChild(styleTag);
            }
            if (data.web_logo_path == 'logo_mexico_custom.png') {
                var styleTag = document.createElement("link");
                styleTag.setAttribute('href', '/images/mexico/Q_logo.png');
                styleTag.setAttribute('type', 'image/x-icon');
                styleTag.setAttribute('rel', 'shortcut icon');
                $("head")[0].appendChild(styleTag);
            }
            Page.theme = data.user_web_theme;
            Page.current_card_type = data.current_card_type == "1" ? "1" : "0";
            Page.iad_ready_status = data.iad_ready_status == "0" ? "0" : "1";
            Page.esim_show = data.esim_show == "1" ? "1" : "0";
            Page.onenet = data.onenet == "1" ? "1":"0";
            Page.logoPath = data.web_logo_path;
            Page.dm_platform = data.dm_platform == "1" ? "1":"0";
            Page.level = data.account_level || "3";
            Page.aeraId = data.aeraId;
            var language = data.language.toUpperCase();
            Page.language = language;
                $("script[src^='/js/language/']").remove();
                $.getScript('/js/language/' + language.toLowerCase() + '.js',init);
        }
    });
    if(IsPC()){
        window.location.href = Page.getUrl("/index.html");
    }
    // var pageUrl = sessionStorage.getItem("pageUrl")
    //     if(pageUrl){
    //         $("#app").load(pageUrl)
    //     }
    //     else{
    //         $("#app").load("html/index.html")
    //     }
    var vm = new Vue({
        el:"#app",
        data(){
            return{
                
            }
        },
        methods:{
           
        },
        mounted(){
            // const pageUrl = sessionStorage.getItem("pageUrl")
            // if(pageUrl){
            //     console.log(pageUrl);
            //     $("#app").load(pageUrl)
            // }else{
            //     console.log(8888888);
            //     $("#app").load("html/index.html")
            // }
            //账号在其他设备登录
            setInterval(Page.getDeviceName, 7000);
            
        }
    })
})