/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-11-30 19:13:05
 * @,@LastEditTime: ,: 2021-02-22 21:14:32
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\system_status\device.js
 */
$(document).ready(function () {
    var loading = "-"
    var runStatusName = [DOC.lbl.runtime, DOC.lbl.loadAvg, DOC.lbl.memoryTotal, DOC.lbl.memoryFree, DOC.lbl.memoryCache];
    var deviceName = [DOC.device.model, DOC.device.softwarVersion, DOC.device.hardwareVersion, DOC.device.configVersion, DOC.device.buildTime, DOC.device.gitBranch, DOC.device.gitCommit, "SN", DOC.device.realVersion, DOC.info.simStatus, DOC.device.idu_firmware_version,
    DOC.device.idu_config_version, DOC.device.idu_config_type, DOC.device.idu_git_branch, DOC.device.idu_git_sha, DOC.device.idu_build_time, DOC.device.idu_memory_total,DOC.device.impower];
    var lteInfoName = [DOC.device.modemVersion, DOC.device.modsoftversion, DOC.device.modhardwareversion, "IMEI", "IMSI", "ICCID","MSISDN", "SN"];
    var vm = new Vue({
        el:"#device-info",
        data(){
            return{
                runStatus: DOC.title.run,
                device: DOC.title.device,
                lteInfo: DOC.title.lte,
                title1:MENU.info.version,
                runStatusValues: [],
                deviceValues: [],
                lteInfoValues: [],
                runStatusName: runStatusName,
                deviceName: deviceName,
                lteInfoName: lteInfoName,
                activeName: ['1','2','3'],
                temperature: ''
            }
        },
        methods:{
            onClickLeft(){
                $("#app").load("html/index.html")
                pageUrl = "html/index.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.DEVICE_INFO
                    },
                    success: function (data) {
                        vm.$set(vm.runStatusValues, 0, ConvertUtil.parseUptime2(data.uptime) || loading);
                        vm.$set(vm.runStatusValues, 1, data.cpuload || loading);
                        var memory = data.memory;
    
                        var memoryArr = memory.split(",");
                        vm.$set(vm.runStatusValues, 2, memoryArr[0] || loading);
                        vm.$set(vm.runStatusValues, 3, memoryArr[1] || loading);
                        vm.$set(vm.runStatusValues, 4, memoryArr[2] || loading);
                        
                        if(Page.level != "3" && !!data.device_temperature) {
                            vm.temperature = data.device_temperature + '℃';
                        }
                       
                        vm.$set(vm.deviceValues, 0, data.board_type || loading);
                        vm.$set(vm.deviceValues, 1, data.fake_version || loading);
                        if (Page.pageHideCheck(109) || Page.aeraId == "MX0268" || Page.aeraId == "MX0268-DOM_CL" || (Page.aeraId == "CN0025" && Page.level == "2")) {
                            vm.$set(vm.deviceValues, 2, data.hwversion || loading);
                        }
                        if (Page.level != "3") {
                            vm.$set(vm.deviceValues, 3, data.config_version || loading);
                            vm.$set(vm.deviceValues, 7, data.device_sn || loading);
                        }
                        if (Page.level == "1") {
                            vm.$set(vm.deviceValues, 4, data.build_date || loading);
                            vm.$set(vm.deviceValues, 5, data.git_branch || loading);
                            vm.$set(vm.deviceValues, 6, data.git_sha || loading);
                            vm.$set(vm.deviceValues, 8, data.real_fwversion || loading);
                            vm.$set(vm.deviceValues, 9, data.sim_slot || loading);
                            vm.$set(vm.deviceValues, 10, data.idu_firmware_version || loading);
                            vm.$set(vm.deviceValues, 11, data.idu_config_version || loading);
                            vm.$set(vm.deviceValues, 12, data.idu_dev_type || loading);
                            vm.$set(vm.deviceValues, 13, data.idu_git_branch || loading);
                            vm.$set(vm.deviceValues, 14, data.idu_git_sha || loading);
                            vm.$set(vm.deviceValues, 15, data.idu_build_time || loading);
                            vm.$set(vm.deviceValues, 16, data.idu_memory_total || loading);
                            vm.$set(vm.deviceValues, 17, data.verify_status || loading);
                        }
                        
    
                        vm.$set(vm.lteInfoValues, 0, data.module_type || loading);
                        vm.$set(vm.lteInfoValues, 1, data.module_softver || loading);
                        vm.$set(vm.lteInfoValues, 2, data.module_hardver || loading);
                        vm.$set(vm.lteInfoValues, 3, data.module_imei || loading);
                        vm.$set(vm.lteInfoValues, 4, data.IMSI || loading);
                        vm.$set(vm.lteInfoValues, 5, data.ICCID || loading);
                        vm.$set(vm.lteInfoValues, 6, data.device_msisdn || loading);
                        vm.$set(vm.lteInfoValues, 7, data.module_sn || loading);

                    }
                })
            },
            lteInfoNameShow: function (index) {
                if (Page.level == "1") {
                  return true;
                } else {
                    if (index == "3" || index == "4" || index == "5" || index == "6") {
                        return true;
                    } else {
                        return false;
                    }
                }
            }
        },
        mounted(){
            this.getData();
            this.lteInfoNameTable = Page.level;
            Page.timer = setInterval(function () {
                vm.getData();
            }, 3000);
        }
    })
})