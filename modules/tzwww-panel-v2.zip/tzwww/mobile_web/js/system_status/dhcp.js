/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-11-30 10:23:56
 * @,@LastEditTime: ,: 2020-12-08 14:04:44
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\system_status\dhcp.js
 */
$(document).ready(function () {
    var loading = "-";
    var lan_names = [DOC.lan.lannet, DOC.net.dhcpServer, DOC.lan.netmask, DOC.lan.beginip, DOC.lan.endip, DOC.lan.intermac, DOC.lan.intername];
    var lan_values = new Array(6);
    var vm = new Vue({
        el:"#status-dhcp",
        data(){
            return{
                active:0,
                lan_names: lan_names,
                lan_values: lan_values,
                deviceList:[],
                show: false,
                dhcp:MENU.info.dhcp,
                lanTitle:networkconfightml.tab_menu.item3,
                title2:networkconfig2html.helper.title2,
                radiusIp:wirelessconfightml.form1.radiusIp,
                leaseTime:DOC.net.leaseTime,
                expires:"",
                ip:"",
                mac:""
            }
        },
        methods:{
            onClickLeft(){
                $("#app").load("html/index.html")
                pageUrl = "html/index.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            clickTab(value){
                if(value==1){
                    this.getDeviceInfo();
                    Page.timer = setInterval(function () {
                        vm.getDeviceInfo();
                    }, 3000);
                }
            },
            showDetail(value){
                this.show = true
                this.expires = this.leaseTimeText(value.expires);
                this.ip = value.ip;
                this.mac = value.mac;
            },
            leaseTimeText(event) {
                function formatDate(date) {
                    var year = date.getFullYear();
                    var month = date.getMonth() + 1;
                    var day = date.getDate();
                    var hour = date.getHours();
                    var minute = date.getMinutes();
                    var second = date.getSeconds();
                    //  return year+"-"+month+"-"+date+" "+hour+":"+minute+":"+second; 
                    return year + '-' + (String(month).length > 1 ? month : '0' + month) + '-' +
                        (String(day).length > 1 ? day : '0' + day) + ' ' + (String(hour).length > 1 ? hour : '0' + hour) + ':' + (String(minute).length > 1 ? minute : '0' + minute) +
                        ':' + (String(second).length > 1 ? second : '0' + second)
                }
                var time = parseInt(event, 10) * 1000;
                if (isNaN(time)) {
                    return "-"
                }
                var d = new Date(time)
                return formatDate(d)
            },
            getDHCPInfo() {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.LAN_INFO
                    },
                    success: function (data) {
                        vm.$set(lan_values, 0, data.lan_ip || loading);
                        vm.$set(lan_values, 1, data.lan_dhcp_enable == "1" ? DOC.status.enable : DOC.status.disable);
                        vm.$set(lan_values, 2, data.lan_netmask || loading);
                        vm.$set(lan_values, 3, data.dhcp_start_ip || loading);
                        vm.$set(lan_values, 4, data.dhcp_end_ip || loading);
                        vm.$set(lan_values, 5, data.lan_mac || loading);
                        vm.$set(lan_values, 6, data.lan_real_iface || loading);
    
    
                    }
                })
    
            },
            getDeviceInfo(){
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.DHCPCLIENT_INFO,
                        method: JSONMethod.GET
                    },
                    success: function (datas) {
                        vm.deviceList = datas.dhcp_list_info;

                    }
                });
            },
            
        },
        mounted(){
            this.getDHCPInfo();
        }
    })
})