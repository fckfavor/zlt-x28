/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-11-26 15:29:39
 * @,@LastEditTime: ,: 2021-08-17 20:18:28
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\index.js
 */
$(document).ready(function () {
    var vm = new Vue({
        el:"#index",
        data(){
            return{
                selecLanguage:DOC.login.language,
                logoutLang:DOC.link.logout,               
                value:1,
                language:"中文",
                show:false,
                selectIndex:"",
                logo:"",
                menu:{
                    xitong:{
                        title:MENU.info.head,
                        icon:"iconfont icon-xitongzhuangtai",
                        menuCategory:[]
                    },
                    wangluo:{
                        title:MENU.setting.wan,
                        icon:"iconfont icon-wangluo",
                        menuCategory:[
                            {
                                name:TAB.advance.networkSet,
                                icon:"iconfont icon-yidongwangluo2"
                            },
                            {
                                name:DOC.apn.setting,
                                icon:"iconfont icon-apn"
                            },
                        ]
                    },
                    wifi:{},
                    equip:{
                        title:HELP.head.wizardDevice,
                        icon:"iconfont icon-shebei",
                        menuCategory:[]
                    },
                    system:{
                        title:MENU.sys.manage,
                        icon:"iconfont icon-xitongguanli",
                        menuCategory:[
                            {
                                name:MENU.sys.settings,
                                icon:"iconfont icon-shezhi"
                            },
                            {
                                name:MENU.sys.reboot,
                                icon:"iconfont icon-zhongqi"
                            }
                        ]
                    }
                },
                languageSelectList:[],
                langList:[]
            }
        },
        methods:{
            openLang(){
                this.show = true;
                this.selectIndex = this.getIndex;
            },
            changeLanguageSelect: function (item) {
              vm.show = false
              Page.postJSON({
                json: {
                  cmd: RequestCmd.CHANGE_LANGUAGE,
                  method: JSONMethod.POST,
                  sessionId: "",
                  languageSelect: item.value
                },
                success: function (data) {
                              var href = location.href;
                  if (href.indexOf('#') > -1) {
                    href = href.substring(0, href.indexOf('#'));
                  }
                  if (href.indexOf('?') > -1) {
                    href = href.substring(0, href.indexOf('?'));
                              }
                              location.href = Page.getUrl(href);
                          },
                complete: function () {
                }
              });
            },
            getLanguageList(){
                Page.postJSON({
                json: {
                    cmd: RequestCmd.INIT_PAGE
                },
                success: function (data) {
                    vm.languageSelectList = [];
                    vm.logo = "../../images/"+data.web_logo_path;
                    var supportLanguage = []
                    if (data.language_support) {
                        supportLanguage = parseInt(data.language_support, 16).toString(2).split("").reverse();
                        var minLength = Math.min(Page.getSupportlanguageList.length, supportLanguage.length);
                        for (var i = 0; i < minLength; i++) {
                            if (supportLanguage[i] == "1") {
                                vm.languageSelectList.push(Page.getSupportlanguageList[i])
                                
                            }
                        }
                    } else {
                        vm.languageSelectList = Page.getSupportlanguageList;
                    }
                    vm.langList = JSON.parse(JSON.stringify(vm.languageSelectList))
                    vm.langList.forEach(function (item) {
                        item.text = item.name
                        delete item.name
                    })
                }
            });
            
            },
            logout(){
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.LOGOUT,
                        method: JSONMethod.POST
                    },
                    success: function (data) {
                        var option = {
                            expireHours: -1,
                            path: '/',
                            domain: location.hostname
                        };
                        CookieUtil.deleteCookie("sessionId", option);
                        sessionStorage.clear();
                        location.href = Page.getUrl("/mobile_web/login.html");
                    }
                });
            },
            goInfo(index,key){
                var idx = index+key;
                var pageUrl="";
                if((Page.iad_ready_status != "1" && Page.level != "1") && idx=="xitong2"){
                  idx = "xitong4"
                }
                switch (idx) {
                    case "xitong0":
                        $("#app").load("html/system_status/wan.html")
                        pageUrl = "html/system_status/wan.html"
                        break;
                    case "xitong1":
                        $("#app").load("html/system_status/dhcp.html")
                        pageUrl = "html/system_status/dhcp.html"
                        break;
                    case "xitong2":
                        $("#app").load("html/system_status/wifi4G.html")
                        pageUrl = "html/system_status/wifi4G.html"
                        break;
                    case "xitong3":
                        $("#app").load("html/system_status/wifi5G.html")
                        pageUrl = "html/system_status/wifi5G.html"
                        break;
                    case "xitong4":
                        $("#app").load("html/system_status/device.html")
                        pageUrl = "html/system_status/device.html"
                        break;
                    case "wangluo0":
                        $("#app").load("html/internet_function/mobile.html")
                        pageUrl = "html/internet_function/mobile.html"
                        break;
                    case "wangluo1":
                        $("#app").load("html/internet_function/apn.html")
                        pageUrl = "html/internet_function/apn.html"
                        break;
                    case "wifi0":
                        $("#app").load("html/wifi_config/wifi24G.html")
                        pageUrl = "html/wifi_config/wifi24G.html"
                        break;
                    case "wifi1":
                        $("#app").load("html/wifi_config/24gSet.html")
                        pageUrl = "html/wifi_config/24gSet.html"
                        break;
                    case "wifi2":
                        $("#app").load("html/wifi_config/wifi5G.html")
                        pageUrl = "html/wifi_config/wifi5G.html"
                        break;
                    case "wifi3":
                        $("#app").load("html/wifi_config/5gSet.html")
                        pageUrl = "html/wifi_config/5gSet.html"
                        break;
                    case "wifi4":
                        $("#app").load("html/wifi_config/wps.html")
                        pageUrl = "html/wifi_config/wps.html"
                        break;
                    case "equip0":
                        $("#app").load("html/device_config/dhcp.html")
                        pageUrl = "html/device_config/dhcp.html"
                        break;
                    case "equip1":
                        $("#app").load("html/device_config/route.html")
                        pageUrl = "html/device_config/route.html"
                        break;
                    case "equip2":
                        $("#app").load("html/device_config/tr069.html")
                        pageUrl = "html/device_config/tr069.html"
                        break;
                    case "system0":
                        $("#app").load("html/system_manage/setting.html")
                        pageUrl = "html/system_manage/setting.html"
                        break;
                    case "system1":
                        this.reboot();
                        break;
                    default:
                        break;
                }
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            reboot(){
                vant.Dialog.confirm({
                    message: PROMPT.confirm.reboot,
                    confirmButtonText:DOC.btn.confirm,
                    cancelButtonText:PROMPT.tips.cancel
                  })
                    .then(function() {
                        loading(PROMPT.status.rebooting);
                        Page.postJSON({
                            json: {
                                cmd: RequestCmd.SYS_REBOOT,
                                rebootType: 1,
                                method: JSONMethod.POST
                            },
                            success: function() {
                                
                            },
                            
                        });
                        successReboot();
                    })
                    .catch(function() {
                    //   vm.getData()
                    });
            }
        },
        created(){
            this.getLanguageList();
        },
        mounted(){
          this.menu.equip.menuCategory = this.menuDeviceConfig;
          this.menu.wifi = this.menuWifiConfig;
          this.menu.xitong.menuCategory =this.menuStatus;
        },
        computed:{
            getIndex(){
                switch (Page.language) {
                    case "CN":
                        return 0
                    case "EN":
                        return 1
                    default:
                        break;
                }
            },
            menuStatus(){
              var tempArray = [];
              if(Page.iad_ready_status == "1" || Page.level == "1"){
                tempArray.push({
                  name:MENU.info.wan,
                  icon:"iconfont icon-wan"
                },
                {
                    name:MENU.info.dhcp,
                    icon:"iconfont icon-WDS"
                },
                {
                    name:MENU.info.wifi24,
                    icon:"iconfont icon-wifi"
                },
                {
                    name:MENU.info.wifi5,
                    icon:"iconfont icon-icwifi48px"
                },
                {
                    name:MENU.info.version,
                    icon:"iconfont icon-shebei"
                })
              }else{
                tempArray.push({
                  name:MENU.info.wan,
                  icon:"iconfont icon-wan"
                },
                {
                    name:MENU.info.dhcp,
                    icon:"iconfont icon-WDS"
                },
                {
                    name:MENU.info.version,
                    icon:"iconfont icon-shebei"
                })
              }
              return tempArray;
            },
            menuDeviceConfig(){
              var tempArray = [{
                name:networkconfightml.form1.title,
                icon:"iconfont icon-WDS"
              }];
              if (Page.pageHideCheck2(68)) {
                tempArray.push({
                      name:MENU.setting.route,
                      icon:"iconfont icon-luyouqi"
                  })
              }
              if (Page.level == "1" || Page.level == "2") {
                tempArray.push({
                  name:TAB.advance.tr069,
                  icon:"iconfont icon-TR"
                })
              }
              return tempArray;
            },
            menuWifiConfig(){
              var tempObject = {};
              if(Page.iad_ready_status == "1" || Page.level == "1"){
                tempObject = {
                  title:MENU.settingWifi.head,
                  icon:"iconfont icon-WIFI",
                  menuCategory:[
                      {
                          name:MENU.settingWifi.wifi,
                          icon:"iconfont icon-WIFI"
                      },
                      {
                          name:MENU.settingWifi.wifiAdvance,
                          icon:"iconfont icon-wifi"
                      },
                      {
                          name:MENU.settingWifi.wifi5g,
                          icon:"iconfont icon-WIFI"
                      },
                      {
                          name:MENU.settingWifi.wifi5gAdvance,
                          icon:"iconfont icon-wifi"
                      },
                      {
                          name:wirelessconfightml.tab_menu.wps,
                          icon:"iconfont icon-wps"
                      },
                  ]
                }
              }
              return tempObject;
            }
        }
    })
})