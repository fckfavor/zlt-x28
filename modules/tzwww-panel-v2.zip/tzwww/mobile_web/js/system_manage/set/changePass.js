/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-12-07 09:28:29
 * @,@LastEditTime: ,: 2021-08-26 10:55:28
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\system_manage\set\changePass.js
 */
$(document).ready(function () {
    var index = sessionStorage.getItem("index")
    var vm = new Vue({
        el:"#set-pass",
        data(){
            return{
                title:TAB.sys.changePasswd,
                title2:DOC.sys.oldPasswd,
                title3:CHECK.required.oldPasswd,
                title4:DOC.sys.newPasswd,
                title5:CHECK.range.passwd,
                title6:CHECK.required.duplicateNewPasswd,
                oldPasswd:DOC.sys.oldPasswd,
                newPasswd:DOC.sys.newPasswd,
                colon:DOC.colon,
                duplicateNewPasswd:DOC.sys.duplicateNewPasswd,
                btnSave:DOC.btn.save,
                btnSave:DOC.btn.save,
                show:false,
                oldPass: '',
                newPass: '',
                affirmPass:"",
            }
        },
        methods:{
            onClickLeft(){
                $("#app").load("html/system_manage/setting.html")
                pageUrl = "html/system_manage/setting.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            formatter(value) {
                // 过滤输入的空格
                return value.replace(/\s/g, '');
              },
            btnSaveClick:function(){
                var reg=/^[0-9a-zA-Z!#$*\+,\-\.%:=\?@\[\]\^_\{|\}~]+$/;
                if(!reg.test(this.newPass)){
                    failLoad(CHECK.format.loginPass);
                    return false;
                }
               var json = {};
               if(vm.newPass != vm.affirmPass)
                {
                    failLoad(CHECK.format.passwdNotSame)
                    return false;
                }
                
               json.cmd = RequestCmd.CHANGE_PASSWD;
               json.method = JSONMethod.POST;
               json.newPasswd = Base64.encode(this.newPass);
               json.old_passwd = Base64.encode(this.oldPass);
               json.subcmd = 0;
               vant.Dialog.confirm({
                message: PROMPT.saving.changeSuccess,
                confirmButtonText:DOC.btn.confirm,
                cancelButtonText:PROMPT.tips.cancel
              }).then(()=>{
                Page.postJSON({
                  json: json,
                  success: function(data) {
                      if(data.message == "success"){
                          vm.oldPass = "";
                          vm.newPass = "";
                          vm.affirmPass = "";
                          clearToast();
                          successLoad();
                          Page.postJSON({
                           json: {
                               cmd: RequestCmd.LOGOUT,
                               method: JSONMethod.POST
                           },
                           success: function (data) {
                               var option = {
                                   expireHours: -1,
                                   path: '/',
                                   domain: location.hostname
                               };
                               CookieUtil.deleteCookie("sessionId", option);
                               sessionStorage.clear();
                               location.href = Page.getUrl("/mobile_web/login.html");
                           }
                         });
                      }else if(data.message == "passwd error"){
                          failLoad(PROMPT.saving.previousPasswd)
                      }else{
                          failLoad()
                      }
                      
                  }
                });
              })
               
            },
        },
        mounted(){
            this.$nextTick(()=>{
                this.$refs.oldPass.focus()
            })
        }
    })
})