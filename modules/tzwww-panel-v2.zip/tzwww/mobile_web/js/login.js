/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-11-26 15:29:29
 * @,@LastEditTime: ,: 2021-09-01 18:57:46
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\login.js
 */
$(function () {
    if(IsPC()){
        window.location.href = Page.getUrl("/login.html");
    }
    var web_browser_title = ""
    function init() {
          if(Page.logoPath !='logo_mexico_custom.png'){
              document.title = web_browser_title || DOC.head
          }else{
              document.title = "Quamtum Connect 1"
          }
        $.ajax({
            url: "/mobile_web/html/loginIndex.html",
            dataType: "html",
            type: "GET",
            async: false,
            success: function (data) {
                $('#login').html(data);
                
            }
        });
    }
    // $("#login").load("html/loginIndex.html")   //
    Page.postJSON({
        json: {
            cmd: RequestCmd.INIT_PAGE
        },
        success: function (data) {
            var styleTag = document.createElement("link");
            Page.webPageFlag = Page.parseHexPageHide(data.web_page_hide);
            var themeWeb = "";
            if (!data.user_web_theme) {
                themeWeb = "css/main.css";
            } else if(data.user_web_theme=="main.tot.css"){
                themeWeb = data.user_web_theme;
            }else{
              themeWeb = "css/main.css";
            }
            if (!!data.web_browser_title) {
                web_browser_title = data.web_browser_title;
            }
            styleTag.setAttribute('href', 'css/' + themeWeb);
            styleTag.setAttribute('type', 'text/css');
            styleTag.setAttribute('rel', 'stylesheet');
            $("head")[0].appendChild(styleTag);
            if( data.web_logo_path == "logo_t3.png") {
              var styleTag = document.createElement("link");
              styleTag.setAttribute('href', 't3_favicon.ico');
              styleTag.setAttribute('type', 'image/x-icon');
              styleTag.setAttribute('rel', 'shortcut icon');
              $("head")[0].appendChild(styleTag);
            }
            if( data.user_web_theme == 'main.tot.css') {
              var styleTag = document.createElement("link");
              styleTag.setAttribute('href', '/images/nn90j-whejs.png');
              styleTag.setAttribute('type', 'image/x-icon');
              styleTag.setAttribute('rel', 'shortcut icon');
              $("head")[0].appendChild(styleTag);
            }
            if (data.web_logo_path == 'logo_mexico_custom.png') {
                var styleTag = document.createElement("link");
                styleTag.setAttribute('href', '/images/mexico/Q_logo.png');
                styleTag.setAttribute('type', 'image/x-icon');
                styleTag.setAttribute('rel', 'shortcut icon');
                $("head")[0].appendChild(styleTag);
            }
            Page.theme = data.user_web_theme;
            Page.current_card_type = data.current_card_type == "1" ? "1" : "0";
            Page.iad_ready_status = data.iad_ready_status == "0" ? "0" : "1";
            Page.esim_show = data.esim_show == "1" ? "1" : "0";
            Page.onenet = data.onenet == "1" ? "1":"0";
            Page.dm_platform = data.dm_platform == "1" ? "1":"0";
            Page.logoPath = data.web_logo_path;
            Page.level = data.account_level || "3";
            var language = data.language.toUpperCase();
            Page.language = language;
            $("script[src^='/js/language/']").remove();
            $.getScript('/js/language/' + language.toLowerCase() + '.js',init);
        }
    });
    var vm = new Vue({
        el:"#login",
        data:{
               
        },
        methods:{
            
        },
        mounted(){
            
        },
    })
})