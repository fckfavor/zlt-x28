/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-12-03 14:02:27
 * @,@LastEditTime: ,: 2021-08-25 15:25:42
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\wifi_config\24gSet.js
 */
$(document).ready(function () {
    var form1 = wirelessconfightml.form1;
    var vm = new Vue({
        el:"#wifi24-set",
        data(){
            return{
                title:MENU.settingWifi.wifiAdvance,
                title1:wlan5ghtml.form1.btnSave,
                wifitxPower: form1.txPower,
                wifichannel: form1.channel,
                wifiMode: form1.wifiMode,
                wifibandwidth: wlan5ghtml.form1.bandWidth,
                wifiNum: wirelessconfightml.helper.title8_2 + ":",
                btnSave: form1.btnSave,
                txOption: [{
                    text: "100%",
                    value: '100'
                },
                {
                    text: "70%",
                    value: '70'
                },
                {
                    text: "50%",
                    value: '50'
                },
                {
                    text: "35%",
                    value: '35'
                },
                {
                    text: "15%",
                    value: '15'
                }
                ],
                channelOption: [{
                    text: form1.auto,
                    value: "auto"
                },
                {
                    text: "1",
                    value: "1"
                },
                {
                    text: "2",
                    value: "2"
                },
                {
                    text: "3",
                    value: "3"
                },
                {
                    text: "4",
                    value: "4"
                },
                {
                    text: "5",
                    value: "5"
                },
                {
                    text: "6",
                    value: "6"
                },
                {
                    text: "7",
                    value: "7"
                },
                {
                    text: "8",
                    value: "8"
                },
                {
                    text: "9",
                    value: "9"
                },
                {
                    text: "10",
                    value: "10"
                },
                {
                    text: "11",
                    value: "11"
                },
                {
                    text: "12",
                    value: "12"
                },
                {
                    text: "13",
                    value: "13"
                }
            ],
            wifiWorkMode: [{
                    text: "11b only",
                    value: "0"
                },
                {
                    text: "11g only",
                    value: "1"
                },
                {
                    text: "11n only",
                    value: "2"
                },
                {
                    text: "11b/g",
                    value: "3"
                },
                {
                    text: "11g/n",
                    value: "4"
                },
                // { text: "11b/g", value: "5" },
                {
                    text: "11b/g/n",
                    value: "6"
                },
            ],
            bandWidthOption: [
                {
                    text: "20MHz",
                    value: "0"
                },
                {
                    text: "40MHz",
                    value: "1"
                },
                {
                    text: "20/40MHz",
                    value: "2"
                },
            ],
            wifiWmmVal: false,
            channel_option: "auto",
            channel_optionVal:"",
            wifi_workMode: "11b only",
            wifi_workModeVal:"",
            band_width: "40MHz",
            band_widthVal:"",
            tx_power: "",
            tx_powerVal:"",
            maxNum: "",
            show:false,
            show2:false,
            show3:false,
            show4:false,
            powerIndex:"",
            channelIndex:"",
            bandWithIndex:"",
            bandValue:"",
            linkNumOption:[],
            show5:false,
            linktNumIndex:"",
            }
        },
        methods:{
            onClickLeft(){
                $("#app").load("html/index.html")
                pageUrl = "html/index.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            openPowe(){
                this.powerIndex = this.getPowerIndex;
                this.show = true;
            },
            openChannel(){
                this.channelIndex = this.channel_optionVal == "auto"?0:Number(this.channel_optionVal);
                this.show2 = true;
            },
            openWorkmode(){
                this.workModeIndex = this.wifi_workModeVal == "6"?5:Number(this.wifi_workModeVal)
                this.show3 = true;
            },
            openBandwith(){
                this.bandWithIndex = Number(this.band_widthVal);
                this.show4 = true;
            },
            onSelect4(item){
                this.show4 = false;
                this.band_width = item.text;
                this.band_widthVal = item.value;
            },
            onSelect3(item){
                this.show3 = false;
                this.wifi_workMode = item.text;
                this.wifi_workModeVal = item.value;
            },
            onSelect2(item){
                this.show2 = false;
                this.channel_option = item.text;
                this.channel_optionVal = item.value;
            },
            onSelect5(item){
                this.show5 = false;
                this.maxNum = item.value;
            },
            openLinkNum(){
              this.show5 = true;
              this.linktNumIndex = this.maxNum-1
            },
            onSelect(item){
                this.show = false;
                this.tx_power = item.text;
                this.tx_powerVal = item.value;
            },
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.WIRELESS_ADVANCE,
                        methods: JSONMethod.GET
                    },
                    success: function (data) {
                        for(var i =0;i<vm.txOption.length;i++){
                            if(data.txPower == vm.txOption[i].value){
                                vm.tx_power = vm.txOption[i].text;
                            }
                        }
                        for(var i =0;i<vm.channelOption.length;i++){
                            if(data.channel == vm.channelOption[i].value){
                                vm.channel_option = vm.channelOption[i].text;
                            }
                        }
                        for(var i =0;i<vm.wifiWorkMode.length;i++){
                            if(data.wifiWorkMode == vm.wifiWorkMode[i].value){
                                vm.wifi_workMode = vm.wifiWorkMode[i].text
                            }
                        }
                        vm.tx_powerVal = data.txPower;
                        vm.channel_optionVal = data.channel;
                        vm.wifi_workModeVal = data.wifiWorkMode;
                        vm.band_width = data.bandWidth == "0"?"20MHz":data.bandWidth == "2"?"20/40MHz":"40MHz";
                        vm.maxNum = data.maxNum;
                        vm.band_widthVal = data.bandWidth
                        vm.wifiWmmVal = data.wifiwmm === '1' ? true : false;
                        vm.eliminateNum = data.eliminateNum || 0;
                        vm.connectNum = data.connectNum || 0;
                    }
                })
            },
            save(){
                loading();
                var json = {};
                json.wifiOpen = "1";//默认
                json.txPower = vm.tx_powerVal;
                json.channel = vm.channel_optionVal;
                json.wifiWorkMode = vm.wifi_workModeVal;
                json.bandWidth = vm.band_width=="20MHz"?"0":vm.band_width=="40MHz"?"1":"2";
                json.maxNum = vm.maxNum;
                json.wifiwmm = vm.wifiWmmVal ? '1' : '0';
                json.eliminateNum = vm.eliminateNum || 0;
                json.connectNum = vm.connectNum || 0;
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.WIRELESS_ADVANCE;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.success == true) {
                            setTimeout(function () {
                                clearToast();
                                successLoad()
                            }, 6000);
                        } else {
                            setTimeout(function () {
                                failLoad()
                            }, 6000);
                        }
                    }
                })
            }
        },
        mounted(){
            this.getData();
            for(var i =1;i<33;i++){
              this.linkNumOption.push({
                text:i,
                value:i.toString()
              })
            }
        },
        computed:{
            getPowerIndex(){
                switch(vm.tx_powerVal){
                    case "100":
                        return 0
                    case "75":
                        return 1
                    case "50":
                        return 2
                    case "35":
                        return 3
                    case "15":
                        return 4
                    default:
                        break
                }
            }
        }
    })
})