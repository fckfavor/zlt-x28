/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-12-04 09:26:09
 * @,@LastEditTime: ,: 2021-03-10 10:04:44
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\device_config\dhcp.js
 */
$(document).ready(function () {
    var form = networkconfightml.form1;
    var showText = networkconfightml.prompt;
    var vm = new Vue({
        el:"#device-dhcp",
        data(){
            return{
                hour:DOC.unit.hour,
                th1: form.th1,
                th2: form.th2,
                th3: form.th3,
                title:MENU.setting.dhcp,
                enable: DOC.status.enable,
                disable: DOC.status.disable,
                checkIP:CHECK.format.ip,
                netmaskCheck: CHECK.required.netmaskCheck,
                linkDomainInvalid:CHECK.format.dns,
                rebooting:PROMPT.status.rebooting,
                btnSave: form.btnSave,
                th6: form.th6,
                th7: form.th7,
                th4: form.th4,
                th5: form.th5,
                td5: form.td5,
                lanIp: '',
                netMask: '',
                dhcpServer: false,
                main_dns: '',
                vice_dns: '',
                ipBegin: '',
                ipEnd: '',
                expireTime: '',
                mainDNSTip:"",
                lanIpTip:"",
                ipEndTip:"",
                noproblem:true,
                pattern:/^((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]).){3}(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])(?::(?:[0-9]|[1-9][0-9]{1,3}|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-5]))?$/,
                pattern1:/^(?:\d{1,2}|1\d\d|2[0-4]\d|25[0-5])(?:\.(?:\d{1,2}|1\d\d|2[0-4]\d|25[0-5])){3}$/
            }
        },
        methods:{
            onClickLeft(){
                $("#app").load("html/index.html")
                pageUrl = "html/index.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            validator(val){
                return /^(?:\d{1,2}|1\d\d|2[0-4]\d|25[0-5])(?:\.(?:\d{1,2}|1\d\d|2[0-4]\d|25[0-5])){3}$/.test(val)
            },
            validator1(val){
                if(val){
                    return  /^((([1-9]|([1-9]\d)|(1\d\d)|(2([0-4]\d|5[0-5]))))\.)((([0-9]|([1-9]\d)|(1\d\d)|(2([0-4]\d|5[0-5]))))\.){2}(([1-9]|([1-9]\d)|(1\d\d)|(2([0-4]\d|5[0-5]))))$/.test(val)
                }
                
            },
            validateGateway: function(wanIp, netmaskIp, gatewayIp) {
                var i1,i2,i3, wip, nip, gip;
                var lan4, mask4, pool4, net_no, lo_broadcast;
    
                i1=wanIp.indexOf('.');
                i2=wanIp.indexOf('.',(i1+1));
                i3=wanIp.indexOf('.',(i2+1));
                wip = this.hex(wanIp.substring(0,i1)) + this.hex(wanIp.substring((i1+1),i2)) +this.hex(wanIp.substring((i2+1),i3))+this.hex(wanIp.substring((i3+1),wanIp.length));
                wip = '0x'+wip;
                lan4 = wanIp.substring((i3+1),wanIp.length)-0;
    
                i1=netmaskIp.indexOf('.');
                i2=netmaskIp.indexOf('.',(i1+1));
                i3=netmaskIp.indexOf('.',(i2+1));
                nip = this.hex(netmaskIp.substring(0,i1)) + this.hex(netmaskIp.substring((i1+1),i2)) +this.hex(netmaskIp.substring((i2+1),i3)) +this.hex(netmaskIp.substring((i3+1),netmaskIp.length));
                nip = '0x'+nip;
                mask4 = netmaskIp.substring((i3+1),netmaskIp.length)-0;
    
                i1=gatewayIp.indexOf('.');
                i2=gatewayIp.indexOf('.',(i1+1));
                i3=gatewayIp.indexOf('.',(i2+1));
                gip = this.hex(gatewayIp.substring(0,i1)) + this.hex(gatewayIp.substring((i1+1),i2)) +this.hex(gatewayIp.substring((i2+1),i3)) +this.hex(gatewayIp.substring((i3+1),gatewayIp.length));
                gip = '0x'+gip;
                pool4 = gatewayIp.substring((i3+1),gatewayIp.length)-0;
    
                if (this.Op_AND_4Byte(wip, nip) != this.Op_AND_4Byte(gip, nip)) {
                    return false;
                }
    
                net_no = (lan4 & mask4);
                lo_broadcast =  (lan4 & mask4) + (255-mask4);
    
                return !(pool4==net_no || pool4==lo_broadcast);
            },
            
            Op_AND_4Byte: function (v1, v2) {
                var i;
                var var1 = [];
                var var2 = [];
                var result='0x';
    
                for (i=2,j=0;i<10;i+=2,j++) {
                    var1[j]='0x'+v1.substring(i,i+2);
                    var2[j]='0x'+v2.substring(i,i+2);
                }
    
                for (i=0;i<4;i++) {
                    result = result + this.hex(var1[i]&var2[i]);
                }
    
                return result - 0;
            },
    
            hex:function(val) {
                var h = (val-0).toString(16);
                if(h.length==1) h='0'+h;
                return h.toUpperCase();
            },
    
            validateStartEndIp: function(lan_ipaddr, netip, startip, endip, DHCP_flag) {
                i1 = startip.indexOf('.');
                i2 = startip.indexOf('.', (i1 + 1));
                i3 = startip.indexOf('.', (i2 + 1));
                sip = this.hex(startip.substring(0, i1)) + this.hex(startip.substring((i1 + 1), i2)) + this.hex(startip.substring((i2 + 1), i3)) + this.hex(startip.substring((i3 + 1), startip.length));
                sip = '0x' + sip;
    
                i1=endip.indexOf('.');
                i2=endip.indexOf('.',(i1+1));
                i3=endip.indexOf('.',(i2+1));
                eip = this.hex(endip.substring(0,i1)) + this.hex(endip.substring((i1+1),i2)) +this.hex(endip.substring((i2+1),i3))+this.hex(endip.substring((i3+1),endip.length));
                eip = '0x'+eip;
    
                i1=lan_ipaddr.indexOf('.');
                i2=lan_ipaddr.indexOf('.',(i1+1));
                i3=lan_ipaddr.indexOf('.',(i2+1));
    
                var compLanIp = '0x' + this.hex(lan_ipaddr.substring(0,i1)) + this.hex(lan_ipaddr.substring((i1+1),i2)) +this.hex(lan_ipaddr.substring((i2+1),i3))+this.hex(parseInt(lan_ipaddr.substring((i3+1),lan_ipaddr.length)) + 18);
                lan_ipaddr = this.hex(lan_ipaddr.substring(0,i1)) + this.hex(lan_ipaddr.substring((i1+1),i2)) +this.hex(lan_ipaddr.substring((i2+1),i3))+this.hex(lan_ipaddr.substring((i3+1),lan_ipaddr.length));
                lan_ipaddr = '0x'+lan_ipaddr;
    
                if(sip>eip) {
                    return 1;
                }
    
                if(lan_ipaddr >= sip && lan_ipaddr <= eip) {
                    return 2;
                }
    
                return 0;
            },
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.NETWORK_CONFIG,
                        methods: JSONMethod.GET
                    },
                    success: function (data) {
                        vm.lanIp = data.lanIp;
                        vm.netMask = data.netMask;
                        vm.dhcpServer = data.dhcpServer == "1" ? true : false;
                        vm.main_dns = data.main_dns;
                        vm.vice_dns = data.vice_dns;
                        vm.ipBegin = data.ipBegin;
                        vm.ipEnd = data.ipEnd;
                        vm.expireTime = data.expireTime.split("h")[0];
                        // vm.isOpenDhcpServer = data.dhcpServer == "1" ? true :false;
                    }
                });
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.IP_MAC_BINDING,
                        method: JSONMethod.GET,
                        getfun: true
                    },
                    success: function (data) {
                        if (data.datas.length > 0) {
                            vm.ipBand = data.datas;
                        }
                    }
                });
            },
            changeIp(){
                var index = this.lanIp.lastIndexOf(".");
                this.main_dns = this.lanIp.substr(0, index) + this.main_dns.substr(this.main_dns
                    .lastIndexOf("."));
                this.ipBegin = this.lanIp.substr(0, index) + this.ipBegin.substr(this.ipBegin
                    .lastIndexOf("."));
                this.ipEnd = this.lanIp.substr(0, index) + this.ipEnd.substr(this.ipEnd
                    .lastIndexOf("."));
            },
            checkData(){
                if(vm.main_dns==""){
                    vm.mainDNSTip = CHECK.format.dns2
                    this.noproblem = false;
                    return false;
                }else{
                    vm.mainDNSTip = "";
                    this.noproblem = true;
                }
                var ipBeginLast = this.ipBegin.substring(this.ipBegin.lastIndexOf(".") + 1);
                var ipEndLast = this.ipEnd.substring(this.ipEnd.lastIndexOf(".") + 1);
                if (vm.dhcpServer&&parseInt(ipEndLast, 10) < parseInt(ipBeginLast, 10)) {
                    vm.ipEndTip = DOC.apn.rule
                    this.noproblem = false;
                    return false;
                }else{
                    vm.ipEndTip = "";
                    this.noproblem = true;
                }
                
            },
            onSubmit(){
                var result = this.validateGateway(this.lanIp, this.netMask, this.ipBegin);
                var result1 = this.validateGateway(this.lanIp, this.netMask, this.ipEnd);
                if(!result){
                    failLoad(CHECK.format.dhcpCheck);
                    return false;
                }
                if(!result1){
                    failLoad(CHECK.format.dhcpCheck1);
                    return false;
                }
                
                if(!this.noproblem){
                    return false;
                }
                var json = {};
                json.lanIp = this.lanIp;
                json.netMask = this.netMask;
                json.dhcpServer = this.dhcpServer ? "1" : "0";
                if (this.dhcpServer) {
                    json.main_dns = this.main_dns;
                    json.vice_dns = this.vice_dns;
                    json.ipBegin = this.ipBegin;
                    json.ipEnd = this.ipEnd;
                    json.expireTime = this.expireTime + "h";
                }
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.NETWORK_CONFIG;
                vant.Dialog.confirm({
                    message: PROMPT.tips.rebootMessage,
                    confirmButtonText:DOC.btn.confirm,
                    cancelButtonText:PROMPT.tips.cancel
                  })
                    .then(() => {
                        Page.postJSON({
                            json: json,
                            success: function (data) {
                                if (data.message == "") {
                                    loading(vm.rebooting+'...');
                                    Page.postJSON({
                                        json: {
                                            cmd: RequestCmd.SYS_REBOOT,
                                            rebootType: 2,
                                            method: JSONMethod.POST
                                        },
                                        success: function() {
                                            
                                        },
                                        
                                    });
                                    var timer = setInterval(() => {
                                        Page.postJSON({
                                            json: { cmd: RequestCmd.ROUTER_INFO },
                                            success: function(res) {
                                                if(res.success){
                                                    clearToast();
                                                    successLoad();
                                                    clearInterval(timer);
                                                    location.reload();
                                                }
                                            }
                                        })
                                    }, 5000);
                                    
                                } else {
                                    failLoad()
                                }
                            }
                        })
                    })
                    .catch(() => {
                      vm.getData()
                    });
            }
        },
        mounted(){
            this.getData()
        },
        watch:{
            dhcpServer(val){
                if(!val&&this.lanIpTip!=""){
                    this.lanIpTip = "";
                    this.noproblem = true;
                }
            }
        }
    })
})
