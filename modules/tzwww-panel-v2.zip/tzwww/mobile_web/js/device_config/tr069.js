/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2021-08-16 13:48:58
 * @,@LastEditTime: ,: 2021-08-16 16:13:36
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\device_config\tr069.js
 */
$(document).ready(function(){
  var vm = new Vue({
      el:"#device-tr069",
      data(){
          return{
            enabled:false,
            tr069Status:DOC.status.disconnected,
            tr069AuthType:"None",
            url:"",
            noticeEnabled:false,
            noticeInterval:"",
            connectionRequestPort:"",
            acsAuthEnabled:false,
            userName:"",
            passwd:"",
            cpeAuthEnabled:false,
            linkUserName:"",
            linkPasswd:""
          }
      },
      methods:{
        validator(value){
          var reg = /^(((ht|f)tps?):\/\/)?[\w-]+(\.[\w-]+)+([\w.,@?^=%&:/~+#-]*[\w@?^=%&/~+#-])?$/;
          return reg.test(value);
        },
        validator1(value){
          if(value<30){
            return false;
          }
        },
        validator2(value){
          if(value.length>0){
            if(value<1025 || value>65535){
              return false;
            }
          }
        },
        validator3(value){
          if(value.length>0){
            if(value.length<2 || value.length>20){
              return false;
            }
          }
        },
        validator4(value){
          if(value.length>0){
            if(value.length<3 || value.length>63){
              return false;
            }
          }
        },
        validator5(value){
          var reg = /^[0-9a-zA-Z!#$&()*\+,\-\.\/%:;<=>?@\[\]^_\{|\}~]*$/;
		      return reg.test(value);
        },
        onClickLeft(){
          $("#app").load("html/index.html")
          pageUrl = "html/index.html"
          sessionStorage.setItem("pageUrl",pageUrl)
        },
        onSubmit(){

          loading();
          var json = {};
          json.enabled = vm.enabled ? "1" : "0";
          json.url = vm.url;
          json.noticeEnabled = vm.noticeEnabled ? "1" : "0";
          json.noticeInterval = vm.noticeInterval;
          json.acsAuthEnabled = vm.acsAuthEnabled ? "1" : "0";
          json.userName = vm.userName;
          json.passwd = vm.passwd;
          json.cpeAuthEnabled = vm.cpeAuthEnabled ? "1" : "0";
          json.linkUserName = vm.linkUserName;
          json.linkPasswd = vm.linkPasswd;
          json.connectionRequestPort = vm.connectionRequestPort;
          json.method = JSONMethod.POST;
          json.cmd = RequestCmd.TR069_CONFIG;
          Page.postJSON({
              json: json,
              success: function (data) {
                  vm.butAble = false;
                  if (data.success == true) {
                    vm.getData();
                    clearToast();
                    successLoad();
                  }else{
                    failLoad();
                  }
              }
          })
        },
        getData:function(){
          Page.postJSON({
            json: { cmd: RequestCmd.TR069_CONFIG,methods:JSONMethod.GET},
            success:function(data){
                vm.enabled = data.enabled == "1" ? true : false;
                vm.url = data.url;
                vm.noticeEnabled = data.noticeEnabled == "1" ? true : false;
                vm.noticeInterval = data.noticeInterval;
                vm.acsAuthEnabled = data.acsAuthEnabled == "1" ? true : false;
                vm.userName = data.userName;
                vm.passwd = data.passwd;
                vm.cpeAuthEnabled = data.cpeAuthEnabled == "1" ? true : false;
                vm.linkUserName = data.linkUserName;
                vm.linkPasswd = data.linkPasswd;
                if(!vm.enabled)
                {
                    vm.tr069Status = DOC.status.disconnected;
                }else
                {
                    vm.tr069Status = data.tr069_connect_status == "connected" ? DOC.status.connected : DOC.status.disconnected;
                }
                vm.tr069AuthType = data.tr069_auth_type == "" ? "None" :  data.tr069_auth_type;
                // vm.apn = data.apn;
                vm.connectionRequestPort = data.connectionRequestPort;
            }
         })
        },
      },
      mounted(){
        this.getData();
      }
    })
  })