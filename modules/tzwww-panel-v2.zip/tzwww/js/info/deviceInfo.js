var loading = "-";
var deviceName = [
    DOC.device.model,
    DOC.sys.make,
    DOC.device.softwarVersion,
    DOC.device.hardwareVersion,
    DOC.device.configVersion,
    DOC.device.buildTime,
    DOC.device.gitBranch,
    DOC.device.gitCommit,
    "SN",
    DOC.device.realVersion,
    DOC.info.simStatus
];
var lteInfoName = [
    DOC.device.modemVersion,
    DOC.device.modsoftversion,
    DOC.device.modhardwareversion,
    "IMEI",
    "IMSI",
    "ICCID",
    "MSISDN",
    "SN"
];
var deviceValues = new Array(10);
var lteInfoValues = new Array(8);
var vm = new Vue({
    el: "#deviceInfo",
    data: {
        deviceValues: deviceValues,
        lteInfoValues: lteInfoValues,
        deviceName: deviceName,
        lteInfoName: lteInfoName,
        lteInfoNameTable: true,
        uptime: "",
        cpuload: "",
        memoryTotal: "",
        memoryAvailable: "",
        memoryFree: "",
        memoryCached: "",
        colorLevel: "",
        memoryPecentage: 0,
        system_version: "",
        verify_status: "",
        flashTotal: "",
        flashAvaileble: "",
        flashColor: "",
        flashPecentage: 0,
        deviceTemperature: "",
        deviceTemperaturePecentage: 0,
        deviceTemperatureColor: "",
        rateList: []
    },
    methods: {
        getColorValue: function (colorLevel) {
            var color = "";
            switch (colorLevel) {
                case "1":
                    color = "red";
                    break;
                case "2":
                    color = "yellow";
                    break;
                case "3":
                    color = "#67c23a";
                    break;
                default:
                    color = "";
            }
            return color;
        },
        getData: function () {
            Page.postJSON({
                json: {
                    cmd: RequestCmd.DEVICE_INFO
                },
                success: function (data) {
                    vm.uptime = ConvertUtil.parseUptime2(data.uptime) || loading;
                    vm.cpuload = data.cpu_usage ? (data.cpu_usage + '%') : loading;
                    var memory = data.memory;
                    var memoryArr = memory.split(",");
                    for (var i = 0; i < memoryArr.length; i++) {
                        memoryArr[i] = parseInt(memoryArr[i].match(/\d+/)[0]);
                    }
                    vm.memoryTotal = FormatUtil.formatByteSize(memoryArr[0]) || loading;
                    vm.memoryAvailable = FormatUtil.formatByteSize(memoryArr[0] - memoryArr[3]) || loading;
                    vm.memoryFree = FormatUtil.formatByteSize(data.memoryFree.match(/\d+/)[0]) || loading;
                    vm.memoryCached = FormatUtil.formatByteSize(memoryArr[2]) || loading;
                    vm.memoryPecentage = parseInt(((memoryArr[0] - memoryArr[3]) / memoryArr[0]) * 100) || 1;
                    vm.colorLevel = vm.getColorValue(data.memoryLevel);
                    const rateList = [];
                    data.negotiatton_rate?.split(",")?.forEach((rate, index) => {
                        const lanIndex = index + 1
                        // AE0001 user账号移除 Link Speed和CPU ratio
                        if(Page.aeraId=='AE0001' && Page.level == '3') return
                        if (rate && Number(rate) > 0) {
                          rateList.push({
                              label: `${Page.wanIndex === lanIndex ? "WAN" : String.format(DOC.lbl.networkPort, lanIndex)} ${DOC.lbl.negotiationRate}`,
                              value: rate + " Mbps"
                          });
                        }
                    });
                    vm.rateList = rateList

                    if (Page.level != "3") {
                        vm.deviceTemperature = data.device_temperature || "";
                        vm.deviceTemperaturePecentage = ((parseInt(data.device_temperature) + 20) * 100) / 140; // 设备温度的取值范围是-20~120
                        vm.deviceTemperatureColor = vm.getColorValue(data.deviceTemperatureLevel);
                    } else {
                        vm.deviceTemperaturePecentage = 0;
                        vm.deviceTemperature = "";
                    }
                    vm.$set(deviceValues, 0, data.board_type || loading);
                    if (Page.aeraId == "SA0465") {
                        vm.$set(deviceValues, 1, "tongzekangwei");
                    }
                    vm.$set(deviceValues, 2, data.fake_version || loading);
                    if (
                        Page.pageHideCheck(109) ||
                        Page.aeraId == "MX0268" ||
                        Page.aeraId == "MX0268-DOM_CL" ||
                        (Page.aeraId == "CN0025" && Page.level == "2")
                    ) {
                        vm.$set(deviceValues, 3, data.hwversion || loading);
                    }
                    if (Page.level != "3") {
                        vm.$set(deviceValues, 4, data.config_version || loading);
                        vm.$set(deviceValues, 8, data.device_sn || loading);
                    }
                    if (Page.level == "1") {
                        vm.$set(deviceValues, 5, data.build_date || loading);
                        vm.$set(deviceValues, 6, data.git_branch || loading);
                        vm.$set(deviceValues, 7, data.git_sha || loading);
                        vm.$set(deviceValues, 9, data.real_fwversion || loading);
                        vm.$set(deviceValues, 10, data.sim_slot || loading);

                        if (!!data.flash_total && !!data.flash_availeble) {
                            vm.flashTotal = parseInt(data.flash_total.match(/\d+/)[0]) || 0;
                            vm.flashAvaileble = vm.flashTotal - parseInt(data.flash_availeble.match(/\d+/)[0]) || 0;
                            vm.flashColor = vm.getColorValue(data.flash_level);
                            vm.flashPecentage = parseInt((vm.flashAvaileble / vm.flashTotal) * 100) || 1;
                        } else {
                            vm.flashPecentage = 0;
                        }
                        vm.verify_status = data.verify_status || loading;
                    }
                    if (!isHide(seniorHide.web_page_hide_set_2) || Page.level == "1") {
                        vm.system_version = data.system_version || loading;
                    }

                    vm.$set(lteInfoValues, 0, data.module_type || loading);
                    vm.$set(lteInfoValues, 1, data.module_softver || loading);
                    vm.$set(lteInfoValues, 2, data.module_hardver || loading);
                    vm.$set(lteInfoValues, 3, data.module_imei || loading);
                    vm.$set(lteInfoValues, 4, data.IMSI || loading);
                    vm.$set(lteInfoValues, 5, data.ICCID || loading);
                    vm.$set(lteInfoValues, 6, data.device_msisdn || loading);
                    vm.$set(lteInfoValues, 7, data.module_sn || loading);
                }
            });
        },
        lteInfoNameShow: function (index) {
            if (Page.level == "1") {
                return true;
            } else {
                if (index == "3" || index == "4" || index == "5" || index == "6") {
                    return true;
                } else {
                    if (Page.aeraId == "IN0345" && index == "7") {
                        return true;
                    } else {
                        return false;
                    }
                }
            }
        },
        format: function () {
            return this.memoryAvailable + DOC.device.used + " / " + this.memoryTotal + DOC.device.total;
        },
        formatFlash: function () {
            return (
                FormatUtil.formatByteSize(this.flashAvaileble) +
                DOC.device.used +
                " / " +
                FormatUtil.formatByteSize(this.flashTotal) +
                DOC.device.total
            );
        },
        formatTemperature: function () {
            return this.deviceTemperature + "℃";
        }
    },
    mounted: function () {
        this.getData();
        this.lteInfoNameTable = Page.level;
        Page.timer = setInterval(function () {
            vm.getData();
        }, 3000);
    }
});
