$(document).ready(function () {
    //校验函数
    function validateIp(rule, value,callback){
        if(!value || value == "") callback();
        var reg = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
        var tag = true;
        if (reg.test(value)) {
            var arr = value.split('.')
            for (var i = 0; i < arr.length; i++) {
                if ((arr[i].length > 1 && arr[i][0] == '0') || arr[i] > 255) {
                    rule.messages = CHECK.format.ip;
                    if(rule.flagType == 'dns')rule.messages = CHECK.format.dns;
                    tag = false;
                    break;
                }
            }
            if (tag && (arr[0] == "0" || arr[0] == "127" || arr[0] >= 224 || arr[3] == "0" || arr[3] == "255")) {
                rule.messages = CHECK.format.ipRule;
                if(rule.flagType == 'dns')rule.messages = CHECK.format.abnormalDns;
                tag = false;
            }
        } else {
            rule.messages = CHECK.format.ip;
            if(rule.flagType == 'dns')rule.messages = CHECK.format.dns;
            tag = false;
        }
        if(tag) callback()
        else callback(rule.message)
    }
    function validateSubmask(rule, value,callback){
        if(!value || value == "") callback();
        var reg = /^(254|252|248|240|224|192|128|0)\.0\.0\.0$|^(255\.(254|252|248|240|224|192|128|0)\.0\.0)$|^(255\.255\.(254|252|248|240|224|192|128|0)\.0)$|^(255\.255\.255\.(255|254|252|248|240|224|192|128|0))$/
        if(reg.test(value)) callback()
        else callback(rule.message)
    }
    function validateIpv6(rule, value, callback){
        if(!value || value=='') return callback();
        var ipv6Regex1 = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/; // fd05:bae0:fa6b:0:3b60:878a:be80:d710格式1
        var ipv6Regex2 = /^(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}$/; // fd05:bae0:fa6b::ba7格式2
        if (!ipv6Regex1.test(value) && !ipv6Regex2.test(value)) {
            callback(rule.message)
        }
        var loopbackRegex = /^(?:0*:){7}1$/; // IPv6回环地址
        var multicastRegex = /^ff[0-9a-f]{2}/i; // IPv6组播地址
        if (loopbackRegex.test(value) || multicastRegex.test(value)) {
            callback(rule.message)
        }
        callback()
    }
    function validateMac(rule, value, callback){
        var reg = /^([0-9a-f]{2}[\:\-]{0,1}){5}[0-9a-f]{2}$/i;
        var invalidMac = ['FF:FF:FF:FF:FF:FF', '00:00:00:00:00:00', '01:00:00:00:00:00'];
        if (reg.test(value)) {
            var val = value.match(/[0-9a-f]{2}/ig).join(":").toUpperCase();
            if(invalidMac.indexOf(val) > -1) {
                callback(rule.message)
            }
            var char = parseInt(val.split(':')[0],16).toString(2).slice(-1)
            if(char=='1') callback(rule.message)
            callback()
        }else callback(rule.message)
    }
    function validateRangeDigits(rule, value, callback){
        var reg = /^\d+$/;
        if(reg.test(value) && value >= rule.range[0] && value <= rule.range[1]) callback()
        else callback(rule.message)
    }
    function validateRepeat(rule, value, callback){
        let tag = rule.data.indexOf(value)
        if(tag != -1 && rule.flag != tag) callback(rule.message)
        else callback()
    }
    var vm = new Vue({
        el: "#apnSetting_template",
        data: {
            dialogFormVisible: false,
            formLabelWidth: '240px',
            flag: 0, //当前修改的APN的标识
            multiWanNum: 0,
            multiWanList: [],
            vlanIdList:[],
            formData: {
                vlan_id : '',
                ipversion : 'IPV4',
                mtu : '',
                ipmode : 'dhcp',
                nat_sw : '1',
                ipaddr4 : '',
                submask4 : '',
                gateway4 : '',
                first_dns : '',
                sec_dns : '',
                ipmode_v6 : '1',
                ipaddr6 : '',
                ipv6_len : '',
                gateway6 : '',
                first_dns6 : '',
                sec_dns6 : '',
                username : '',
                passwd : '',
                mac_clone : '',
            },
            IpVersion_opt: [
                { name: "IPv4", value: "IPV4"},
                { name: "IPv6", value: "IPV6"},
                { name: "IPv4/IPv6", value: "IPV4V6"},
            ],
            IpMode: [
                { name: "DHCP", value: "dhcp"},
                { name: "Static", value: "static"},
                { name: DOC.wiredSetting.pppoeType, value: "linkPPP"},
            ],
        },
        methods: {
            getData: function () {
                var _this = this;
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.MULTI_WAN_SETTING,
                        methods: JSONMethod.GET
                    },
                    success: function (data) {
                        _this.multiWanNum = parseInt(data.multiWanNum);
                        if (_this.multiWanNum === 0) {
                            return false;
                        }
                        var tmp = {};
                        for (var i = 1; i <= _this.multiWanNum; i++) {
                            tmp = {};
                            tmp.wan_sw = data['wan_sw_' + i] == '1' ? true : false;
                            tmp.vlan_id = data['vlan_id_' + i];
                            tmp.ipversion = data['ipversion_' + i]?data['ipversion_' + i].toUpperCase():data['ipversion_' + i];
                            tmp.mtu = data['mtu_' + i];
                            tmp.ipmode = data['ipmode_' + i];
                            tmp.nat_sw = data['nat_sw_' + i];
                            tmp.ipaddr4 = data['ipaddr4_' + i];
                            tmp.submask4 = data['submask4_' + i];
                            tmp.gateway4 = data['gateway4_' + i];
                            tmp.first_dns = data['first_dns_' + i];
                            tmp.sec_dns = data['sec_dns_' + i];
                            tmp.ipmode_v6 = data['ipmode_v6_' + i];
                            tmp.ipaddr6 = data['ipaddr6_' + i];
                            tmp.ipv6_len = data['ipv6_len_' + i];
                            tmp.gateway6 = data['gateway6_' + i];
                            tmp.first_dns6 = data['first_dns6_' + i];
                            tmp.sec_dns6 = data['sec_dns6_' + i];
                            tmp.username = data['username_' + i];
                            tmp.passwd = data['passwd_' + i];
                            tmp.mac_clone = data['mac_clone_' + i];
                            _this.multiWanList.push(tmp);
                            _this.vlanIdList.push(tmp.vlan_id);
                        }
                    }
                })
            },
            btnSaveList: function () {
                var json = {};
                for (var i = 1; i <= this.multiWanNum; i++) {
                    json['wan_sw_' + i] = this.multiWanList[i-1].wan_sw ? '1' : '0';
                    json['vlan_id_' + i] = this.multiWanList[i-1].vlan_id;
                    json['ipversion_' + i] = this.multiWanList[i-1].ipversion;
                    json['mtu_' + i] = this.multiWanList[i-1].mtu;
                    json['ipmode_' + i] = this.multiWanList[i-1].ipmode;
                    json['nat_sw_' + i] = this.multiWanList[i-1].nat_sw;
                    json['ipaddr4_' + i] = this.multiWanList[i-1].ipaddr4;
                    json['submask4_' + i] = this.multiWanList[i-1].submask4;
                    json['gateway4_' + i] = this.multiWanList[i-1].gateway4;
                    json['first_dns_' + i] = this.multiWanList[i-1].first_dns;
                    json['sec_dns_' + i] = this.multiWanList[i-1].sec_dns;
                    json['ipmode_v6_' + i] = this.multiWanList[i-1].ipmode_v6;
                    json['ipaddr6_' + i] = this.multiWanList[i-1].ipaddr6;
                    json['ipv6_len_' + i] = this.multiWanList[i-1].ipv6_len;
                    json['gateway6_' + i] = this.multiWanList[i-1].gateway6;
                    json['first_dns6_' + i] = this.multiWanList[i-1].first_dns6;
                    json['sec_dns6_' + i] = this.multiWanList[i-1].sec_dns6;
                    json['username_' + i] = this.multiWanList[i-1].username;
                    json['passwd_' + i] = this.multiWanList[i-1].passwd;
                    json['mac_clone_' + i] = this.multiWanList[i-1].mac_clone;
                }
                fyAlertMsgLoading();
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.MULTI_WAN_SETTING;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.success) {
                            fyAlertMsgSuccess();
                        }else{
                            fyAlertMsgFail();
                        }
                    }
                })
            },
            editWAN: function (item, index) {
                this.flag = index;
                vm.formData.vlan_id = item.vlan_id
                vm.formData.ipversion = item.ipversion
                vm.formData.mtu = item.mtu
                vm.formData.ipmode = item.ipmode
                vm.formData.nat_sw = item.nat_sw
                vm.formData.ipaddr4 = item.ipaddr4
                vm.formData.submask4 = item.submask4
                vm.formData.gateway4 = item.gateway4
                vm.formData.first_dns = item.first_dns
                vm.formData.sec_dns = item.sec_dns
                vm.formData.ipmode_v6 = item.ipmode_v6
                vm.formData.ipaddr6 = item.ipaddr6
                vm.formData.ipv6_len = item.ipv6_len
                vm.formData.gateway6 = item.gateway6
                vm.formData.first_dns6 = item.first_dns6
                vm.formData.sec_dns6 = item.sec_dns6
                vm.formData.username = item.username
                vm.formData.passwd = item.passwd
                vm.formData.mac_clone = item.mac_clone
                this.dialogFormVisible = true;
            },
            changeWAN: function () {
                this.$refs["formData"].validate(function (valid) {
                    if (valid) {
                        vm.dialogFormVisible = false;
                        if (vm.flag > -1) {
                            vm.multiWanList[vm.flag].vlan_id = vm.formData.vlan_id
                            vm.multiWanList[vm.flag].ipversion = vm.formData.ipversion
                            vm.multiWanList[vm.flag].mtu = vm.formData.mtu
                            vm.multiWanList[vm.flag].ipmode = vm.formData.ipmode
                            vm.multiWanList[vm.flag].nat_sw = vm.formData.nat_sw
                            vm.multiWanList[vm.flag].ipaddr4 = vm.formData.ipaddr4
                            vm.multiWanList[vm.flag].submask4 = vm.formData.submask4
                            vm.multiWanList[vm.flag].gateway4 = vm.formData.gateway4
                            vm.multiWanList[vm.flag].first_dns = vm.formData.first_dns
                            vm.multiWanList[vm.flag].sec_dns = vm.formData.sec_dns
                            vm.multiWanList[vm.flag].ipmode_v6 = vm.formData.ipmode_v6
                            vm.multiWanList[vm.flag].ipaddr6 = vm.formData.ipaddr6
                            vm.multiWanList[vm.flag].ipv6_len = vm.formData.ipv6_len
                            vm.multiWanList[vm.flag].gateway6 = vm.formData.gateway6
                            vm.multiWanList[vm.flag].first_dns6 = vm.formData.first_dns6
                            vm.multiWanList[vm.flag].sec_dns6 = vm.formData.sec_dns6
                            vm.multiWanList[vm.flag].username = vm.formData.username
                            vm.multiWanList[vm.flag].passwd = vm.formData.passwd
                            vm.multiWanList[vm.flag].mac_clone = vm.formData.mac_clone
                        }
                    } else {
                        return false;
                    }
                });
            },
            getNameByVal: function(arr,val){
                return arr.filter(function(item){return item.value == val})[0]?.name
            },
            formatNatSw: function(val){
                return val == '1'?DOC.status.enable : DOC.status.disable
            },
        },
        computed:{
            Dhcpv6Mode(){
                var res =[]
                if(this.formData.ipmode == 'dhcp'){
                    res = [
                        {name:'SLAAC+DHCPv6',value:'2'},
                        {name:DOC.lbl.dhcpv6,value:'1'},
                    ]
                    if(this.formData.ipmode_v6 !='1' && this.formData.ipmode_v6 !='2') this.formData.ipmode_v6 ='2'
                }else if(this.formData.ipmode == 'static'){
                    res = [{name:'Static',value:'4'}]
                    this.formData.ipmode_v6 ='4'
                }else if(this.formData.ipmode == 'linkPPP'){
                    res = [{name:DOC.lbl.PPPoE,value:'5'}]
                    this.formData.ipmode_v6 ='5'
                }
                return res
            },
            rules(){
                return {
                    vlan_id:[
                        { required: true, message: CHECK.required.noEmpty, trigger: 'blur' },
                        { validator: validateRangeDigits, range: [10,4059], message: CHECK.format.vlanRange, trigger: ['blur', 'change'] },
                        { validator: validateRepeat, data: this.vlanIdList, flag: this.flag, message: CHECK.format.vlanId, trigger: ['blur', 'change'] }
                    ],
                    mtu:[
                        { required: true, message: CHECK.required.mtu, trigger: 'blur' },
                        { validator: validateRangeDigits, range: (this.formData.ipversion == 'IPV4'?[576,1500]:[1280,1500]), message: (this.formData.ipversion == 'IPV6'?CHECK.range.MTURange:CHECK.format.MtuRange), trigger: ['blur', 'change'] }
                    ],
                    ipaddr4:[
                        { required: true, message: CHECK.required.noEmpty, trigger: 'blur' },
                        { validator: validateIp, flagType:'ip', message: CHECK.format.formatError,trigger: ['blur', 'change']}
                    ],
                    submask4:[
                        { required: true, message: CHECK.required.noEmpty, trigger: 'blur' },
                        { validator: validateSubmask, message: CHECK.format.netmask,trigger: ['blur', 'change']}
                    ],
                    gateway4:[
                        { required: true, message: CHECK.required.noEmpty, trigger: 'blur' },
                        { validator: validateIp, flagType:'ip',message: CHECK.format.formatError,trigger: ['blur', 'change']}
                    ],
                    first_dns:[
                        { required: true, message: CHECK.required.noEmpty, trigger: 'blur' },
                        { validator: validateIp, flagType:'dns',message: CHECK.format.formatError,trigger: ['blur', 'change']}
                    ],
                    sec_dns:[
                        { validator: validateIp, flagType:'dns',message: CHECK.format.formatError,trigger: ['blur', 'change']}
                    ],
                    ipaddr6:[
                        { required: true, message: CHECK.required.noEmpty, trigger: 'blur' },
                        { validator: validateIpv6 ,message: CHECK.format.formatError,trigger: ['blur', 'change']}
                    ],
                    ipv6_len:[
                        { required: true, message: CHECK.required.mtu, trigger: 'blur' },
                        { validator: validateRangeDigits, range: [1,128], message: CHECK.format.ipv6LenRange, trigger: ['blur', 'change'] }
                    ],
                    gateway6:[
                        { validator: validateIpv6 ,message: CHECK.format.formatError,trigger: ['blur', 'change']}
                    ],
                    first_dns6:[
                        { required: true, message: CHECK.required.noEmpty, trigger: 'blur' },
                        { validator: validateIpv6 ,message: CHECK.format.formatError,trigger: ['blur', 'change']}
                    ],
                    sec_dns6:[
                        { validator: validateIpv6 ,message: CHECK.format.formatError,trigger: ['blur', 'change']}
                    ],
                    username:[
                        { required: true, message: CHECK.required.noEmpty, trigger: 'blur' },
                    ],
                    passwd:[
                        { required: true, message: CHECK.required.noEmpty, trigger: 'blur' },
                    ],
                    mac_clone:[
                        { validator: validateMac ,message: CHECK.format.formatError,trigger: ['blur', 'change']}
                    ]
                }
            }
        },
        mounted: function () {
            this.getData()
        }
    });
});
